package com.example.demo.repositries;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.PlayList;

public interface PlayListRepositry  extends JpaRepository<PlayList,Integer>{

}
