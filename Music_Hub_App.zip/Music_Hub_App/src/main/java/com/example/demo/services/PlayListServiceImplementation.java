package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repositries.PlayListRepositry;

@Service
public class PlayListServiceImplementation implements PlayListService {
	
	@Autowired
	PlayListRepositry prepo;

}
